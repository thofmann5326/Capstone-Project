import requests

# chapter 10.2 - pip
# If not installed, install the requests package from
# a terminal using pip or pip3 for mac.
# pip install requests
# pip3 install requests
response = requests.get("Https://google.com")
print(response)
print(response.url)
# displays the html text returned by the web server
print(response.text)
