from pathlib import Path
from zipfile import ZipFile
import os

import_path = Path("worldbank_zipfiles")
export_path = Path("worldbank_data")

source_to_unzip = []

for path in os.listdir(import_path):
    # check if current path is a file
    if os.path.isfile(os.path.join(import_path, path)):
        folder = r"worldbank_zipfiles/"
        path = folder + path
        source_to_unzip.append(path)
# print(source_to_unzip)

for unzip in source_to_unzip:
    with ZipFile(unzip) as zip:
        # print(zip.namelist())
        # info = zip.getinfo("ecommerce/__init__.py")
        # print(info.file_size)
        zip.extractall(export_path)
    # print("done extracting")
