import sqlite3
from pathlib import Path
import csv

# data = Path("customers.csv").read_text(data)
# print("read all content from a csv file")
with open("customers.csv", encoding='ISO-8859-1') as file:
    reader = csv.reader(file)
    customers = tuple(reader)
    # print(customers)


# print("Getting data")
db_name = "chinook.db"
with sqlite3.connect(db_name) as conn:
    sql_command = "INSERT INTO customers(Company, FirstName, LastName, Address, City, PostalCode, Country, Email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    for customer in customers:
        customer_values = customer
        conn.execute(sql_command, customer_values)
        print("Adding data")
    conn.commit()
