# Follow the instructions for coding a weather app
# Importing the statistics module
# referances
# https://www.geeksforgeeks.org/python-statistics-mean-function/
# https://realpython.com/python-min-and-max/
# https://www.w3schools.com/python/python_lists.asp
import statistics

daily_high_temp = [62, 64, 79, 52, 46, 50, 58, 66, 71, 75, 78, 78, 76, 80, 77]
daily_low_temp = [42, 48, 47, 26, 28, 28, 32, 37, 43, 46, 48, 47, 48, 49, 50]
daily_humidity = [0.48, 0.53, 0.46, 0.44, 0.4, 0.6,
                  0.58, 0.5, 0.48, 0.43, 0.41, 0.39, 0.39, 0.3, 0.4]

# Store the maximum High temperature and the average High temperature

maxHigh = max(daily_high_temp)
avgHigh = round(statistics.mean(daily_high_temp))

# Store the minimum Low temperature and average Low temperature.
minLow = min(daily_low_temp)
avgLow = round(statistics.mean(daily_low_temp))

# Store the average humidity level.
avgHumidity = round(statistics.mean(daily_humidity), 2)

# When displaying the output, round all temperatures to zero decimal places.
# Round humidity to two decimal places.

# Output the client’s example above to the terminal.
# Replace the numbers in the example output with the appropriate variables.
# This output will simulate the plugin for a website.
# You do NOT need to code an actual HTML website plugin.

print(
    f"Weather forecast for the next 15 days: The average low will be {avgLow} and average high will be {avgHigh}. The average humidity will be {avgHumidity}. The highest temperature will be {maxHigh}. The lowest temperature will be {minLow}.")
