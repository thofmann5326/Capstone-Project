# Determines the shipping cost based on the ship_to_state.
# When testing, change the ship_to_state to various state abreviations
# to verify your code works for all conditions.

ship_to_state = input(
    "Enter a state to ship to, e.g. TX, NM, OK, NY, AK, HI, etc.:")
ship_to_state = str.upper(ship_to_state)

if ship_to_state == "TX" or ship_to_state == "NM" or ship_to_state == "OK":
    shipping_cost = 0.00
elif ship_to_state == "NY":
    shipping_cost = 7.00
elif ship_to_state == "AK":
    shipping_cost = 15.75
elif ship_to_state == "HI":
    shipping_cost = 20.00
else:
    shipping_cost = 12.50

print(f"Shipping to {str.upper(ship_to_state)} costs {shipping_cost}.")
