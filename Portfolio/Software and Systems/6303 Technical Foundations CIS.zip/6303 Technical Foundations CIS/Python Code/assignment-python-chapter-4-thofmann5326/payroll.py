# create a function to calculate various taxes for an employee
# see instructions for details

def calc_payroll_tax(gross_pay):
    medicare = 0.0145 * gross_pay
    futa = 0.006 * gross_pay
    ss_tax_employer = 0.062 * gross_pay
    ss_tax_employee = 0.062 * gross_pay
    total_tax = (medicare + futa + ss_tax_employee)
    net_pay = gross_pay - total_tax
    print(f"Gross Pay: $ {gross_pay:.2f}")
    print(f"Medicare Tax: $ {medicare:.2f}")
    print(f"FUTA: $ {futa:.2f}")
    print(f"Social Security Tax paid by employer: $ {ss_tax_employer:.2f}")
    print(f"Social Security Tax paid by employee: $ {ss_tax_employee:.2f}")
    print(f"Total Payroll Tax paid by employee: $ {total_tax:.2f}")
    print(f"Net Pay: $ {net_pay:.2f}")
