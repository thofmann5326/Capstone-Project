print("Hello World")
print("*" * 10)
