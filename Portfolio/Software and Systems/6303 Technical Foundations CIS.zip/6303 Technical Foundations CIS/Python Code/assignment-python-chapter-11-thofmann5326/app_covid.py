import requests

"""
Documentation at 
https://documenter.getpostman.com/view/10808728/SzS8rjbc
"""

# 1. get the API data from the web server
# This API server does not require an API key
# 2. Convert the data into a useful python objects: usually a list or dictionaries
# Set the URL for the API call
url = "https://api.covid19api.com/summary"

# Make the API call and store the response
response = requests.get(url)

# Convert the response to a dictionary object
data = response.json()

# Get the global stats dictionary
global_stats = data['Global']

# Get the total deaths and total confirmed cases from global stats
deaths = global_stats['TotalDeaths']
cases = global_stats['TotalConfirmed']

# Calculate the mortality rate
mortality_rate = deaths / cases

# Print the results
print("Total Deaths: {:,}".format(deaths))
print("Total Confirmed Cases: {:,}".format(cases))
print(f"Mortality Rate: {mortality_rate:.3}")
