# Follow the instructions on what to do with this file
# Do NOT modify the contents of this file

# Functions that simulate posting of a blog
def post_blog():
    print("simulating the posting of a blog")

def post_delete():
    print("simulating the deleting of a blog post")

def post_edit():
    print("simulating the edit of a blog post")
