# Follow the instructions on what to do with this file
# Do NOT modify the contents of this file

#Functions regarding the likes and rating of blogs

def like_blog():
    print("simulating the liking of a blog post")

def dislike_blog():
    print("simulating the down vote of a blog post")

def leader_board():
    print("simulating the display of the post popular bloggers")