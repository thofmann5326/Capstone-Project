from random import random
from array import array
from collections import deque

invite_list = []
value = True
invite_list_count = 0

while value == True:
    name = input("Enter a guest's name or type 'end' to stop. \n")
    # print(name)
    if name.lower() == "end":
        value = False
    else:
        invite_list.append(name)
        invite_list_count += 1

print(*invite_list, sep="\n")

cost = invite_list_count * 12

print(
    f"You have invited {invite_list_count} guests at a cost of ${cost} for food.")
