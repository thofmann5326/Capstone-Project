# Edit this file according to the instructions
# Import various modules needed for this lesson
from random import random
from array import array
from collections import deque
# start coding below this line

# Chapter 5.8 Lamba Functions
print("Chapter 5.8 Lamba Functions" + "-" * 20)
items = [
    ("Product1", 10),
    ("Product2", 9),
    ("Product3", 12)
]

# sort by quantuty
items.sort(key=lambda item: item[1])
print(items)

# sort by sales
star_wars_office = [
    ["Star Wars", 1300],
    ["The Empire Strikes Back", 704.2],
    ["Return of the Jedi", 723.2],
    ["The Phantom Menace", 757.5]
]
star_wars_office.sort(key=lambda item: item[1])
print(star_wars_office)

# sort by movie name
star_wars_office.sort(key=lambda item: item[0])
print(star_wars_office)


# Chapter 5.9 Map function
print("Chapter 5.9 Map function" + "-" * 20)
# Mapping means to create a new list from another, or transform the list
items = [
    ("Product1", 10),
    ("Product2", 9),
    ("Product3", 12)
]

# transform list into a new list, using for loop
prices = []
for item in items:
    prices.append(item[1])

# tansform list into a new list, using lambda
items = [
    ("Product1", 10),
    ("Product2", 9),
    ("Product3", 12)
]

prices = list(map(lambda item: item[1], items))
print(prices)


# Chapter 5.10 Filter Function
print("Chapter 5.10 Filter Function" + "-" * 20)
items = [
    ("Product1", 10),
    ("Product2", 9),
    ("Product3", 12)
]

filtered = list(filter(lambda item: item[1] >= 10, items))
print(filtered)

# another example
sw = [
    ["Star Wars", 1300],
    ["The Empire Strikes Back", 704.2],
    ["Return of the Jedi", 723.2],
    ["The Phantom Menace", 757.5]
]
sw_filtered = list(filter(lambda item: item[1] >= 750.0, sw))
print(sw_filtered)


# Chapter 5.11 list Comprehensions
print("Chapter 5.11 list Comprehensions" + "-" * 20)
# mapping means to create a new list from another, or tansform the list
# this is also called "List Comprehension"
items = [
    ("Product1", 10),
    ("Product2", 9),
    ("Product3", 12)
]

# mapping using labda
prices = list(map(lambda item: item[1], items))

# mapping using pythin's list comprehension. which do you like?
prices = [item[1] for item in items]
print(prices)

# real example of list comprehension
# create 10 random numbers
random_numbers = [random() for item in range(10)]
print(random_numbers)

# filter using lambda
filtered = list(filter(lambda item: item[1] >= 10, items))

# filter using pything's list comprehension. which do you like?
filtered = [item for item in items if item[1] >= 10]
print(filtered)

# Another example using star wars list of box office sales
sw_filtered = list(filter(lambda item: item[1] >= 750.0, sw))
sw_filtered = [item for item in sw if item[1] >= 750.0]
print(sw_filtered)

#
# Chapter 5.12 Zip Function
print("Chapter 5.12 Zip Function" + "-" * 20)
# Zipping Means Combining two or more lists into a list of tuple pairs
list1 = [1, 2, 3]
list2 = [10, 20, 30]

# we want a list of tuples pairs like this [(1,10), (2,20), (3, 10)]
list_combined = list(zip(list1, list2))
print(list_combined)

# example
products = ["product1", "product2", "product3", "product4", "product5"]
sales = [435, 665, 13, 2425, 598]
quantity_sold = [5, 19, 1, 30, 15]
product_sales_quantity_combined = list(zip(products, sales, quantity_sold))
print(product_sales_quantity_combined)

# extra practice with for loop
# note: product, sale, anb quantity are any variable names you desire
for product, sale, quantity in product_sales_quantity_combined:
    print(f"Sales for {product} were $ {sale} with {quantity} units sold.")

