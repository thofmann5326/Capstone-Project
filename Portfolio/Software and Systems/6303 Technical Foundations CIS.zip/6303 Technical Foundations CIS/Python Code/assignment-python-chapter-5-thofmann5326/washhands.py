# Follow the instructions for what to code in this file.

from random import random
from array import array
from collections import deque

table1 = (18.1, 15.4, 19.0, 13.4, 10.2, 13.1,
          18.1, 14.4, 15.0, 10.8, 5.4, 12.2)
table2 = (0.7, 0.0, 0.7, 1.0, 1.1, 0.4, 0.0, 1.0, 2.3, 2.9, 1.3)

# print(table1)
# print(table2)
table1_average = 0
count1 = 0
table2_average = 0
count2 = 0

for num in table1:
    table1_average += num
    count1 += 1

table1_average = table1_average / count1
print("Average mortality rate before hand washing policy: ",
      round(table1_average, 1))

for num in table2:
    table2_average += num
    count2 += 1

table2_average = table2_average / count2
print("Average mortality rate after hand washing policy: ", round(table2_average, 1))
