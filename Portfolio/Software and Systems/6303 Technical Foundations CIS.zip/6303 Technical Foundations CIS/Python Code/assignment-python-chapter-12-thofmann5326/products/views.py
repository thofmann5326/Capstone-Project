from .models import Product
from django.shortcuts import render
from django.http import HttpResponse


def home(request):
    return HttpResponse('Hello World')


def index(request):
    products = Product.objects.all()
    return render(request, 'index.html', {'products': products})


def new(request):
    return HttpResponse('New products')
