SECURITY_KEY = 'django-insecure-#m1z&mlf=#pot)k27#-d$#v^3enezgsm6iewneve1h_(*8#k0@'
