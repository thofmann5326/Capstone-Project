from setuptools import setup

setup(
    name="Assessments",
    version="0.1.1",
    packages=["Assessment"],
)
